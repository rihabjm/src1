import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AjoutformateurComponent } from './ajoutformateur/ajoutformateur.component';
import { SupprimeformateurComponent } from './supprimeformateur/supprimeformateur.component';
import { ModifierformateurComponent } from './modifierformateur/modifierformateur.component';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { FormateurComponent } from './formateur/formateur.component';
import { DetatilsformateurComponent } from './detatilsformateur/detatilsformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
const routes: Routes = [{
         path: 'formateur',component: FormateurComponent,
        children: [

            { path: 'ajouter', component: AjoutformateurComponent} ,
            { path: 'modifier', component: ModifierformateurComponent } ,
            { path: 'supprimer', component: SupprimeformateurComponent } ,
            { path: 'lister', component: ListformateurComponent } ,
             { path: 'details', component:DetatilsformateurComponent  } ,
            { path: 'details/:id', component:DetatilsformateurComponent  } ,
             { path: 'calendrier', component:CalendrierformateurComponent  } ,
                   ]
                       }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormateurRoutingModule {
}
