import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { FormateurRoutingModule } from './formateur-routing.module';
import { AjoutformateurComponent } from './ajoutformateur/ajoutformateur.component';
import { SupprimeformateurComponent } from './supprimeformateur/supprimeformateur.component';
import { ModifierformateurComponent } from './modifierformateur/modifierformateur.component';
import { FormateurComponent } from './formateur/formateur.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { DetatilsformateurComponent } from './detatilsformateur/detatilsformateur.component';
import { CalndrierformateurComponent } from './calndrierformateur/calndrierformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
import { Routes, RouterModule } from '@angular/router';

@NgModule({
  declarations: [AjoutformateurComponent, SupprimeformateurComponent, ModifierformateurComponent, ListformateurComponent, FormateurComponent, DetatilsformateurComponent, CalndrierformateurComponent, CalendrierformateurComponent ],
  imports: [
    CommonModule,
    FormateurRoutingModule ,NgbModule ,FormsModule, ReactiveFormsModule

]
})
export class FormateurModule { }
