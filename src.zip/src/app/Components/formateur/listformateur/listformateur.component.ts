import { Component, OnInit } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import { Router } from '@angular/router';
import { DetatilsformateurComponent } from '../detatilsformateur/detatilsformateur.component';

@Component({
  selector: 'app-listformateur',
  templateUrl: './listformateur.component.html',
  styleUrls: ['./listformateur.component.scss']
})
export class ListformateurComponent implements OnInit {


  constructor(private formateurservice :FormateurService ,private router: Router) { }

  ngOnInit() {
this.getAll() ;
  }

formateur: Formateur[] = new Array();



private getAll() {
 this.formateurservice.getAll().subscribe(data => {
 this.formateur=data ;
      console.log(this.formateur);
    }, ex => {
      console.log(ex);
    });}

 Detailsformateur(id: number){
    this.router.navigate(['details', id]);
  }
}
