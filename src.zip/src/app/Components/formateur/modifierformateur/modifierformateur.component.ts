import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifierformateur',
  templateUrl: './modifierformateur.component.html',
  styleUrls: ['./modifierformateur.component.scss']
})
export class ModifierformateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
