import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutformationmetiersComponent } from './ajoutformationmetiers.component';

describe('AjoutformationmetiersComponent', () => {
  let component: AjoutformationmetiersComponent;
  let fixture: ComponentFixture<AjoutformationmetiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AjoutformationmetiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AjoutformationmetiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
