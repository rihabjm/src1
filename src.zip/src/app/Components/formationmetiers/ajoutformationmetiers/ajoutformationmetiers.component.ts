import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajoutformationmetiers',
  templateUrl: './ajoutformationmetiers.component.html',
  styleUrls: ['./ajoutformationmetiers.component.scss']
})
export class AjoutformationmetiersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
