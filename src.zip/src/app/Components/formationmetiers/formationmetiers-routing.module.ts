import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AjoutformationmetiersComponent } from './ajoutformationmetiers/ajoutformationmetiers.component';
import { ListformationmetiersComponent } from './listformationmetiers/listformationmetiers.component';
import { ModifierformationmetiersComponent } from './modifierformationmetiers/modifierformationmetiers.component';
import { SupprimeformationmetiersComponent } from './supprimeformationmetiers/supprimeformationmetiers.component';
import { FormationmetiersComponent } from './formationmetiers/formationmetiers.component';

const routes: Routes = [{
         path: 'formationmetiers',component: FormationmetiersComponent,
        children: [
            { path: 'ajouterformationmetiers', component:AjoutformationmetiersComponent } ,
            { path: 'modifierformationmetiers', component: ModifierformationmetiersComponent } ,
            { path: 'supprimerformationmetiers', component:SupprimeformationmetiersComponent  } ,
            { path: 'listerformationmetiers', component: ListformationmetiersComponent } ,
                   ]
                       }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormationmetiersRoutingModule { }
