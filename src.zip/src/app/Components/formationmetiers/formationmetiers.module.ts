import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormationmetiersRoutingModule } from './formationmetiers-routing.module';
import { AjoutformationmetiersComponent } from './ajoutformationmetiers/ajoutformationmetiers.component';
import { ListformationmetiersComponent } from './listformationmetiers/listformationmetiers.component';
import { ModifierformationmetiersComponent } from './modifierformationmetiers/modifierformationmetiers.component';
import { SupprimeformationmetiersComponent } from './supprimeformationmetiers/supprimeformationmetiers.component';
import { FormationmetiersComponent } from './formationmetiers/formationmetiers.component';


@NgModule({
  declarations: [AjoutformationmetiersComponent, ListformationmetiersComponent, ModifierformationmetiersComponent, SupprimeformationmetiersComponent, FormationmetiersComponent],
  imports: [
    CommonModule,
    FormationmetiersRoutingModule
  ]
})
export class FormationmetiersModule { }
