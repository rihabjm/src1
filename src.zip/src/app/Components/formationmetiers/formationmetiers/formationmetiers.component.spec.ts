import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormationmetiersComponent } from './formationmetiers.component';

describe('FormationmetiersComponent', () => {
  let component: FormationmetiersComponent;
  let fixture: ComponentFixture<FormationmetiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormationmetiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormationmetiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
