import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formationmetiers',
  templateUrl: './formationmetiers.component.html',
  styleUrls: ['./formationmetiers.component.scss']
})
export class FormationmetiersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
