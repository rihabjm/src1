import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listformationmetiers',
  templateUrl: './listformationmetiers.component.html',
  styleUrls: ['./listformationmetiers.component.scss']
})
export class ListformationmetiersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
