import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifierformationmetiersComponent } from './modifierformationmetiers.component';

describe('ModifierformationmetiersComponent', () => {
  let component: ModifierformationmetiersComponent;
  let fixture: ComponentFixture<ModifierformationmetiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifierformationmetiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifierformationmetiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
