import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifierformationmetiers',
  templateUrl: './modifierformationmetiers.component.html',
  styleUrls: ['./modifierformationmetiers.component.scss']
})
export class ModifierformationmetiersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
