import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupprimeformationmetiersComponent } from './supprimeformationmetiers.component';

describe('SupprimeformationmetiersComponent', () => {
  let component: SupprimeformationmetiersComponent;
  let fixture: ComponentFixture<SupprimeformationmetiersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupprimeformationmetiersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupprimeformationmetiersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
