import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supprimeformationmetiers',
  templateUrl: './supprimeformationmetiers.component.html',
  styleUrls: ['./supprimeformationmetiers.component.scss']
})
export class SupprimeformationmetiersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
