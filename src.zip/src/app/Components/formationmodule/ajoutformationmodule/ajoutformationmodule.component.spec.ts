import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutformationmoduleComponent } from './ajoutformationmodule.component';

describe('AjoutformationmoduleComponent', () => {
  let component: AjoutformationmoduleComponent;
  let fixture: ComponentFixture<AjoutformationmoduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AjoutformationmoduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AjoutformationmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
