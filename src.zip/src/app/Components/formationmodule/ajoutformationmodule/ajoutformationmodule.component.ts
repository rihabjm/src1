import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajoutformationmodule',
  templateUrl: './ajoutformationmodule.component.html',
  styleUrls: ['./ajoutformationmodule.component.scss']
})
export class AjoutformationmoduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
