import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AjoutformationmoduleComponent } from './ajoutformationmodule/ajoutformationmodule.component';
import { ModifierformationmoduleComponent } from './modifierformationmodule/modifierformationmodule.component';
import { SupprimeformationmoduleComponent } from './supprimeformationmodule/supprimeformationmodule.component';
import { ListformationmoduleComponent } from './listformationmodule/listformationmodule.component';
import { FormationmoduleComponent } from './formationmodule/formationmodule.component';

const routes: Routes = [{
         path: 'formationmodule',component: FormationmoduleComponent,
        children: [
            { path: 'ajouterformationmodule', component:AjoutformationmoduleComponent } ,
            { path: 'modifierformationmodule', component: ModifierformationmoduleComponent } ,
            { path: 'supprimerformationmodule', component:SupprimeformationmoduleComponent  } ,
            { path: 'listerformationmodule', component: ListformationmoduleComponent } ,
                   ]
                       }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormationmoduleRoutingModule { }
