import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormationmoduleRoutingModule } from './formationmodule-routing.module';
import { AjoutformationmoduleComponent } from './ajoutformationmodule/ajoutformationmodule.component';
import { ModifierformationmoduleComponent } from './modifierformationmodule/modifierformationmodule.component';
import { SupprimeformationmoduleComponent } from './supprimeformationmodule/supprimeformationmodule.component';
import { ListformationmoduleComponent } from './listformationmodule/listformationmodule.component';
import { FormationmoduleComponent } from './formationmodule/formationmodule.component';


@NgModule({
  declarations: [AjoutformationmoduleComponent, ModifierformationmoduleComponent, SupprimeformationmoduleComponent, ListformationmoduleComponent, FormationmoduleComponent],
  imports: [
    CommonModule,
    FormationmoduleRoutingModule
  ]
})
export class FormationmoduleModule { }
