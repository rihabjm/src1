import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormationmoduleComponent } from './formationmodule.component';

describe('FormationmoduleComponent', () => {
  let component: FormationmoduleComponent;
  let fixture: ComponentFixture<FormationmoduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormationmoduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormationmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
