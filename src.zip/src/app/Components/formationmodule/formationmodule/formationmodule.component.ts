import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formationmodule',
  templateUrl: './formationmodule.component.html',
  styleUrls: ['./formationmodule.component.scss']
})
export class FormationmoduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
