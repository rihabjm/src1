import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListformationmoduleComponent } from './listformationmodule.component';

describe('ListformationmoduleComponent', () => {
  let component: ListformationmoduleComponent;
  let fixture: ComponentFixture<ListformationmoduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListformationmoduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListformationmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
