import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listformationmodule',
  templateUrl: './listformationmodule.component.html',
  styleUrls: ['./listformationmodule.component.scss']
})
export class ListformationmoduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
