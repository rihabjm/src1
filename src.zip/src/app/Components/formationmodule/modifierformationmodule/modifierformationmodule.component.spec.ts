import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifierformationmoduleComponent } from './modifierformationmodule.component';

describe('ModifierformationmoduleComponent', () => {
  let component: ModifierformationmoduleComponent;
  let fixture: ComponentFixture<ModifierformationmoduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifierformationmoduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifierformationmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
