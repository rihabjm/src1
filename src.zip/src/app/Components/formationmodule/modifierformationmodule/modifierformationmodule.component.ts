import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modifierformationmodule',
  templateUrl: './modifierformationmodule.component.html',
  styleUrls: ['./modifierformationmodule.component.scss']
})
export class ModifierformationmoduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
