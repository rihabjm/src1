import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SupprimeformationmoduleComponent } from './supprimeformationmodule.component';

describe('SupprimeformationmoduleComponent', () => {
  let component: SupprimeformationmoduleComponent;
  let fixture: ComponentFixture<SupprimeformationmoduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SupprimeformationmoduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupprimeformationmoduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
