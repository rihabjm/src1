import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-supprimeformationmodule',
  templateUrl: './supprimeformationmodule.component.html',
  styleUrls: ['./supprimeformationmodule.component.scss']
})
export class SupprimeformationmoduleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
