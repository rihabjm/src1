import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ajoutsalle',
  templateUrl: './ajoutsalle.component.html',
  styleUrls: ['./ajoutsalle.component.scss']
})
export class AjoutsalleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
