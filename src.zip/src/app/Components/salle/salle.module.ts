import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SalleRoutingModule } from './salle-routing.module';
import { AjoutsalleComponent } from './ajoutsalle/ajoutsalle.component';
import { SupprimesalleComponent } from './supprimesalle/supprimesalle.component';
import { ListsalleComponent } from './listsalle/listsalle.component';
import { ModifiersalleComponent } from './modifiersalle/modifiersalle.component';
import { SalleComponent } from './salle/salle.component';


@NgModule({
  declarations: [AjoutsalleComponent, SupprimesalleComponent, ListsalleComponent, ModifiersalleComponent, SalleComponent],
  imports: [
    CommonModule,
    SalleRoutingModule
  ]
})
export class SalleModule { }
