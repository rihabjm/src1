import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ouvrirsession',
  templateUrl: './ouvrirsession.component.html',
  styleUrls: ['./ouvrirsession.component.scss']
})
export class OuvrirsessionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
