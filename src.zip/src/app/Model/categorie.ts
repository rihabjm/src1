export class Categorie {
id_categorie :number ;
designation :String ;


}
