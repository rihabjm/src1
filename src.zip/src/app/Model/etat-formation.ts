export class EtatFormation {
  id_etat : number ;
etat : String ;
}
