import { FormationMetiers } from './formation-metiers';

describe('FormationMetiers', () => {
  it('should create an instance', () => {
    expect(new FormationMetiers()).toBeTruthy();
  });
});
