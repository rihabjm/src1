import {Observable} from 'rxjs';
import {Session} from './Session';
export class FormationMetiers {
  idformation:number ;
intitule : String ;
datedebut : Date;
datefin : Date ;
prix :number ;
etat : String;
Promotion :String ;
type: String ;
description :String ;
duree : String ;
 sesions : Observable<Session> ;
}
