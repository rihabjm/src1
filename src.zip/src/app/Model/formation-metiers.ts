
export class FormationMetiers {
  id_formation:number ;
intitule_formation : String ;
langue :String ;
nombreheure :  number;
prix :number ;
Categorie :String;
Date : String;
id_etat : number;
Promotion :String ;
TypeFormation: String ;

}
