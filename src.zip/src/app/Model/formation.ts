import {Observable} from 'rxjs';
import {Session} from './Session';
export class Formation {
 idformation:number ;
intitule : String ;
datedebut : Date;
datefin : Date ;
prix :number ;
etat : String;
type: String ;
description :String ;

}
