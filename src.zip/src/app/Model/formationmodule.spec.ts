import { Formationmodule } from './formationmodule';

describe('Formationmodule', () => {
  it('should create an instance', () => {
    expect(new Formationmodule()).toBeTruthy();
  });
});
