export class Formationmodule {
idformation:number ;
intitule : String ;
prix :number ;
datedebut : String;
datefin:String ;
etat : String;
image :String ;
type: String ;
duree: number ;


}
