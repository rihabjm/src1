export class ImageModel {
}
