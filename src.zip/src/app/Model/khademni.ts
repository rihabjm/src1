export class Khademni {


     societe_daccuiel:String;

     periode :String;

        id_khademni : number;
        intitule : String;

}
