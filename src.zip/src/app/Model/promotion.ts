export class Promotion {
  id_promotion :number ;
  designation :String ;
  details :String ;
  prixreduit :number ;
  	id_date :Date ;
}
