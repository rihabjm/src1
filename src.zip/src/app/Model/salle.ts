export class Salle {
  	id_salle : number ;
     capacitesalle :number ;
numsalle : number ;
occupe : boolean ;
}
