import { FormationMetiers } from './formation-metiers';
export class Session {
  id_session : number  ;
datedebut : Date ;
datefin : Date ;
nombrepartcipant : number ;
}
