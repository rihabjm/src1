export class Type {
  id_type :number ;
	type : String ;


}
