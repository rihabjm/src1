import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Categorie} from '../Model/categorie';
@Injectable({
  providedIn: 'root'
})
export class CategorieService {

  constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/categorie';
public getAll(): Observable<Categorie[]> {
    return this.httpClient.get<Categorie[]>(this.url+'/get');}
}
