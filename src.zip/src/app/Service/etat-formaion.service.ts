import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {EtatFormation} from '../Model/etat-formation';
@Injectable({
  providedIn: 'root'
})
export class EtatFormaionService {

  constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/etatFormation';

  public getAll(): Observable<EtatFormation[]> {
    return this.httpClient.get<EtatFormation[]>(this.url+'/get');
  }

}
