import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Files} from '../Model/files';
@Injectable({
  providedIn: 'root'
})
export class FileService {
 constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL;
 public save(files:Files): Observable<any> {

  return this.httpClient.post(this.url+'/uploadFile',files );
  }

}
