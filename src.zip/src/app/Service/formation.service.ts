import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Formation} from '../Model/formation';
@Injectable({
  providedIn: 'root'
})
export class FormationService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/formation';
 public getformation(intitule): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/byintitule/' + intitule);
  }

}
