import { TestBed } from '@angular/core/testing';

import { FormationmoduleService } from './formationmodule.service';

describe('FormationmoduleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FormationmoduleService = TestBed.get(FormationmoduleService);
    expect(service).toBeTruthy();
  });
});
