import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Session} from '../Model/Session';
@Injectable({
  providedIn: 'root'
})
export class SessionService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/Session';
public save(session :Session): Observable<any> {

  return this.httpClient.post(this.url+'/add',session );
  }

  public  getAll(): Observable<Session[]> {
    return this.httpClient.get<Session[]>(this.url+'/get');
  }
 public update(session :Session): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,session);
  }


   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }

}
