import { Component, OnInit } from '@angular/core';
import {FormationMetiers} from '../../../Model/formation-metiers';
import {FormationMetiersService} from '../../../Service/formation-metiers.service';
@Component({
  selector: 'app-formation-metier-list',
  templateUrl: './formation-metier-list.component.html',
  styleUrls: ['./formation-metier-list.component.css']
})
export class FormationMetierListComponent implements OnInit {

  constructor(private formationsmetiersservice :FormationMetiersService) { }

  ngOnInit() { this.getAll() ;
  }

formationsmetiers: FormationMetiers[] = new Array();
private getAll() {
 this.formationsmetiersservice.getAll().subscribe(data => {
 this.formationsmetiers=data ;
      console.log(this.formationsmetiers);
    }, ex => {
      console.log(ex);
    });}
}
