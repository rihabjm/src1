import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormationMEtierRoutingModule } from './formation-metier-routing.module';
import { FormationMetierComponent } from './formation-metier/formation-metier.component';
import { AddFormationComponent } from './add-formation/add-formation.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { FormationMetierUpdateComponent } from './formation-metier-update/formation-metier-update.component';
import { FormationMetierListComponent } from './formation-metier-list/formation-metier-list.component';

@NgModule({
  declarations: [FormationMetierComponent, AddFormationComponent, FormationMetierUpdateComponent, FormationMetierListComponent],
  imports: [
    CommonModule,
    FormationMEtierRoutingModule ,FormsModule, ReactiveFormsModule
  ]
})
export class FormationMEtierModule { }
