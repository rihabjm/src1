import { Component, OnInit } from '@angular/core';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';
import{EtatFormation} from'../../../Model/etat-formation';
import{EtatFormaionService} from'../../../Service/etat-formaion.service';
import{Categorie} from'../../../Model/categorie';
import {CategorieService} from'../../../Service/categorie.service';
import{Type} from '../../../Model/type';
import {TypeService} from'../../../Service/type.service';
import{Promotion} from '../../../Model/promotion';
import {PromotionService} from'../../../Service/promotion.service';
@Component({
  selector: 'app-formationmodule-add',
  templateUrl: './formationmodule-add.component.html',
  styleUrls: ['./formationmodule-add.component.css']
})
export class FormationmoduleAddComponent implements OnInit {
 fmodule:Formationmodule=new Formationmodule ;
etatformations: EtatFormation[] = new Array() ;
categorieformations: Categorie[] = new Array();
typeformations:Type[]=new Array();
promotionformations:Promotion[]=new Array();
  constructor(private formationmoduleserice: FormationmoduleService , private etatFormationservice :EtatFormaionService , private  categorieService:CategorieService , private typeservice:TypeService ,private promotionservice :PromotionService ) { }

  ngOnInit() {

this.getAllEtat();
this.getAllCategorie();
this.getAllType();
this.getAllPromotion() ;
}

ajouter()
{
this.formationmoduleserice.save(this.fmodule).subscribe( data => {

     if (data.success) {} else {}

}, ex => {console.log(ex);
    });
  }


private getAllEtat() {

  this.etatFormationservice.getAll().subscribe(data => {
this.etatformations=data ;
      console.log(this.etatformations);
    }, ex => {
      console.log(ex);
    });}

private getAllCategorie() {
 this.categorieService.getAll().subscribe(data => {
this.categorieformations=data ;
      console.log(this.categorieformations);
    }, ex => {
      console.log(ex);
    });}


private getAllType() {
 this.typeservice.getAll().subscribe(data => {
 this.typeformations=data ;
      console.log(this.typeformations);
    }, ex => {
      console.log(ex);
    });}


private getAllPromotion() {
 this.promotionservice.getAll().subscribe(data => {
 this.promotionformations=data ;
      console.log(this.promotionformations);
    }, ex => {
      console.log(ex);
    });}


}
