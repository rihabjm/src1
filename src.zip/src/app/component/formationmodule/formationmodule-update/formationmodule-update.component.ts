import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formationmodule-update',
  templateUrl: './formationmodule-update.component.html',
  styleUrls: ['./formationmodule-update.component.css']
})
export class FormationmoduleUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
