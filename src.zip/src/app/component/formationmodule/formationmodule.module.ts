import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormationmoduleRoutingModule } from './formationmodule-routing.module';
import { FormationmoduleComponent } from './formationmodule/formationmodule.component';
import { FormationmoduleUpdateComponent } from './formationmodule-update/formationmodule-update.component';
import { FormationmoduleListComponent } from './formationmodule-list/formationmodule-list.component';
import { FormsModule, ReactiveFormsModule }  from '@angular/forms';
import { FormationmoduleAddComponent } from './formationmodule-add/formationmodule-add.component';

@NgModule({
  declarations: [FormationmoduleComponent, FormationmoduleUpdateComponent, FormationmoduleListComponent, FormationmoduleAddComponent],
  imports: [
    CommonModule,
    FormationmoduleRoutingModule , FormsModule, ReactiveFormsModule
  ]
})
export class FormationmoduleModule { }
